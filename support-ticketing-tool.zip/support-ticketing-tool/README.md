# Support Ticketing Tool

A responsive React + Vite frontend for creating and managing support tickets.

## Requirements
- Node.js 18+ (recommended)
- npm

## Run locally
1. Extract this ZIP.
2. Open the `support-ticketing-tool` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run `npm install`
5. Run `npm run dev`
6. Open the local URL printed by Vite (usually http://localhost:5173).

## Features
- Ticket listing with search and status/priority filters
- Create ticket form with required fields
- Ticket detail view
- Update status, priority, and category
- Summary counts
- Responsive mobile layout
- Saves tickets in browser localStorage

## Build for production
Run `npm run build`. Vite creates the production site in the `dist` folder.

## GitHub Pages note
This project is a Vite app, not a plain HTML page. GitHub Pages needs a build/deployment workflow to publish the `dist` output. Run locally first, then set up GitHub Actions deployment for Vite.
