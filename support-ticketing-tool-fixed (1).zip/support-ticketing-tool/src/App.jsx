import { useEffect, useMemo, useState } from 'react'
import { Plus, Search, LifeBuoy, LayoutDashboard, Ticket as TicketIcon, Settings, Bell, X, ArrowUpRight, Clock3, CheckCircle2, CircleAlert, Menu, ChevronRight } from 'lucide-react'

const initialTickets = [
  { id: 'TK-1048', title: 'Unable to reset my password', description: 'I have tried the password reset link several times, but I never receive the email. Could you help me regain access to my account?', category: 'Account', priority: 'High', status: 'Open', requester: 'Olivia Martin', email: 'olivia@example.com', createdAt: '2026-10-18T09:25:00' },
  { id: 'TK-1047', title: 'Invoice has an incorrect amount', description: 'The latest invoice seems to include a duplicate charge. Please check the billing details.', category: 'Billing', priority: 'Medium', status: 'In Progress', requester: 'Noah Williams', email: 'noah@example.com', createdAt: '2026-10-17T14:10:00' },
  { id: 'TK-1046', title: 'Dashboard takes too long to load', description: 'The dashboard has been loading slowly since yesterday, especially when opening reports.', category: 'Technical', priority: 'High', status: 'In Progress', requester: 'Ava Johnson', email: 'ava@example.com', createdAt: '2026-10-17T11:40:00' },
  { id: 'TK-1045', title: 'How do I change my profile photo?', description: 'I would like to update my profile picture but cannot find the setting.', category: 'General', priority: 'Low', status: 'Resolved', requester: 'Liam Brown', email: 'liam@example.com', createdAt: '2026-10-16T16:05:00' },
  { id: 'TK-1044', title: 'Two-factor authentication setup', description: 'Please guide me through enabling two-factor authentication for my account.', category: 'Account', priority: 'Medium', status: 'Open', requester: 'Emma Davis', email: 'emma@example.com', createdAt: '2026-10-16T08:30:00' },
]
const statuses = ['Open', 'In Progress', 'Resolved']
const priorities = ['Low', 'Medium', 'High', 'Urgent']
const categories = ['Account', 'Billing', 'Technical', 'General', 'Feature Request']
const statusClass = value => value.toLowerCase().replaceAll(' ', '-')
const dateLabel = value => new Date(value).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })

function App() {
  const [tickets, setTickets] = useState(() => {
    try { return JSON.parse(localStorage.getItem('helpdesk-tickets')) || initialTickets } catch { return initialTickets }
  })
  const [selectedId, setSelectedId] = useState('TK-1048')
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('All tickets')
  const [priorityFilter, setPriorityFilter] = useState('All priorities')
  const [showCreate, setShowCreate] = useState(false)
  const [mobileMenu, setMobileMenu] = useState(false)
  const [notice, setNotice] = useState('')
  const [form, setForm] = useState({ title: '', description: '', requester: '', email: '', category: 'Technical', priority: 'Medium' })

  useEffect(() => { localStorage.setItem('helpdesk-tickets', JSON.stringify(tickets)) }, [tickets])
  useEffect(() => { if (notice) { const timer = setTimeout(() => setNotice(''), 2800); return () => clearTimeout(timer) } }, [notice])

  const filtered = useMemo(() => tickets.filter(t => {
    const matchesSearch = `${t.id} ${t.title} ${t.requester} ${t.category}`.toLowerCase().includes(search.toLowerCase())
    return matchesSearch && (statusFilter === 'All tickets' || t.status === statusFilter) && (priorityFilter === 'All priorities' || t.priority === priorityFilter)
  }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), [tickets, search, statusFilter, priorityFilter])
  const selected = tickets.find(t => t.id === selectedId) || filtered[0] || tickets[0]
  const counts = { all: tickets.length, open: tickets.filter(t => t.status === 'Open').length, progress: tickets.filter(t => t.status === 'In Progress').length, resolved: tickets.filter(t => t.status === 'Resolved').length }

  function updateTicket(id, changes) {
    setTickets(current => current.map(t => t.id === id ? { ...t, ...changes } : t))
    setNotice('Ticket updated successfully')
  }
  function createTicket(event) {
    event.preventDefault()
    const ticket = { ...form, id: `TK-${1049 + tickets.length - initialTickets.length}`, status: 'Open', createdAt: new Date().toISOString() }
    setTickets(current => [ticket, ...current]); setSelectedId(ticket.id); setSearch(''); setStatusFilter('All tickets'); setPriorityFilter('All priorities'); setShowCreate(false)
    setForm({ title: '', description: '', requester: '', email: '', category: 'Technical', priority: 'Medium' }); setNotice(`${ticket.id} created successfully`)
  }

  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu ? 'sidebar-open' : ''}`}>
      <div className="brand"><div className="brand-mark"><LifeBuoy size={23} /></div><span>help<span className="brand-light">desk</span></span><button className="mobile-close icon-button" onClick={() => setMobileMenu(false)} aria-label="Close menu"><X size={19}/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav className="nav-list"><button className="nav-item active"><LayoutDashboard size={18}/> Overview</button><button className="nav-item" onClick={() => { setStatusFilter('All tickets'); setMobileMenu(false) }}><TicketIcon size={18}/> All tickets <span className="nav-count">{counts.all}</span></button><button className="nav-item" onClick={() => setStatusFilter('Open')}><CircleAlert size={18}/> Open <span className="nav-count">{counts.open}</span></button><button className="nav-item" onClick={() => setStatusFilter('Resolved')}><CheckCircle2 size={18}/> Resolved</button></nav>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><LifeBuoy size={18}/></div><strong>Need a hand?</strong><p>We're here to help you get things sorted.</p><button onClick={() => setNotice('You are already in the support workspace.')}>Visit help center <ArrowUpRight size={14}/></button></div><button className="nav-item settings-item"><Settings size={18}/> Settings</button><div className="profile"><div className="avatar avatar-purple">SM</div><div className="profile-info"><strong>Swathi M.</strong><span>Support admin</span></div><button className="more-button" aria-label="Profile options">•••</button></div></div>
    </aside>
    {mobileMenu && <button className="scrim" aria-label="Close navigation" onClick={() => setMobileMenu(false)} />}
    <main className="main-content">
      <header className="topbar"><button className="mobile-menu icon-button" onClick={() => setMobileMenu(true)} aria-label="Open menu"><Menu size={21}/></button><div className="breadcrumb">Workspace <ChevronRight size={14}/> <strong>Overview</strong></div><div className="topbar-right"><span className="today-label">Saturday, October 18</span><button className="icon-button notification" aria-label="Notifications" onClick={() => setNotice('You’re all caught up!')}><Bell size={18}/><i/></button><div className="avatar avatar-purple top-avatar">SM</div></div></header>
      <section className="page-wrap"><div className="page-heading"><div><div className="eyebrow">SUPPORT CENTER</div><h1>Good evening, Swathi <span className="wave">✦</span></h1><p className="page-subtitle">Here’s what’s happening with your support tickets today.</p></div><button className="primary-button" onClick={() => setShowCreate(true)}><Plus size={18}/> Create ticket</button></div>
        <section className="stats-grid" aria-label="Ticket summary"><Stat icon={<TicketIcon size={18}/>} label="Total tickets" value={counts.all} note="Across all categories" color="blue"/><Stat icon={<CircleAlert size={18}/>} label="Open tickets" value={counts.open} note="Need your attention" color="orange"/><Stat icon={<Clock3 size={18}/>} label="In progress" value={counts.progress} note="Currently being handled" color="purple"/><Stat icon={<CheckCircle2 size={18}/>} label="Resolved" value={counts.resolved} note="Successfully completed" color="green"/></section>
        <section className="ticket-layout"><div className="ticket-list-panel"><div className="panel-heading"><div><h2>Support tickets</h2><p>Track and manage incoming requests</p></div><button className="filter-button" onClick={() => {setStatusFilter('All tickets');setPriorityFilter('All priorities');setSearch('')}}>Reset filters</button></div>
          <div className="filters"><label className="search-box"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search tickets..." aria-label="Search tickets"/></label><select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} aria-label="Filter by status"><option>All tickets</option>{statuses.map(s => <option key={s}>{s}</option>)}</select><select value={priorityFilter} onChange={e => setPriorityFilter(e.target.value)} aria-label="Filter by priority"><option>All priorities</option>{priorities.map(p => <option key={p}>{p}</option>)}</select></div>
          <div className="ticket-table-wrap"><table className="ticket-table"><thead><tr><th>Ticket</th><th>Status</th><th>Priority</th><th>Created</th></tr></thead><tbody>{filtered.map(ticket => <tr key={ticket.id} onClick={() => setSelectedId(ticket.id)} className={selected?.id === ticket.id ? 'selected-row' : ''} tabIndex="0" onKeyDown={e => e.key === 'Enter' && setSelectedId(ticket.id)}><td><div className="ticket-cell"><span className="ticket-id">{ticket.id}</span><strong>{ticket.title}</strong><span className="ticket-meta">{ticket.category} · {ticket.requester}</span></div></td><td><span className={`status-pill ${statusClass(ticket.status)}`}><i/>{ticket.status}</span></td><td><span className={`priority ${statusClass(ticket.priority)}`}><span/> {ticket.priority}</span></td><td className="date-cell">{dateLabel(ticket.createdAt)}</td></tr>)}</tbody></table>{filtered.length === 0 && <div className="empty-state"><TicketIcon size={28}/><strong>No tickets found</strong><span>Try another search or reset your filters.</span></div>}</div>
          <div className="table-footer"><span>Showing <strong>{filtered.length}</strong> of <strong>{tickets.length}</strong> tickets</span><span className="live-indicator"><i/> Live workspace</span></div>
        </div>
        <div className="details-panel">{selected ? <><div className="details-top"><span className="detail-label">TICKET DETAILS</span><button className="icon-button detail-more" aria-label="Ticket actions" onClick={() => setNotice(`Selected ${selected.id}`)}>•••</button></div><div className="detail-id">{selected.id} <span className={`status-pill ${statusClass(selected.status)}`}><i/>{selected.status}</span></div><h2 className="detail-title">{selected.title}</h2><div className="detail-date">Created on {dateLabel(selected.createdAt)}</div><div className="detail-divider"/><div className="detail-section"><h3>Description</h3><p className="description-text">{selected.description}</p></div><div className="detail-divider"/><div className="detail-section"><h3>Requester</h3><div className="requester"><div className="avatar avatar-peach">{selected.requester.split(' ').map(n => n[0]).slice(0,2).join('')}</div><div><strong>{selected.requester}</strong><span>{selected.email}</span></div></div></div><div className="detail-divider"/><div className="detail-section"><h3>Ticket properties</h3><label className="field-label" htmlFor="status-select">Status</label><select id="status-select" className="detail-select" value={selected.status} onChange={e => updateTicket(selected.id, {status:e.target.value})}>{statuses.map(s => <option key={s}>{s}</option>)}</select><label className="field-label" htmlFor="priority-select">Priority</label><select id="priority-select" className="detail-select" value={selected.priority} onChange={e => updateTicket(selected.id, {priority:e.target.value})}>{priorities.map(p => <option key={p}>{p}</option>)}</select><label className="field-label" htmlFor="category-select">Category</label><select id="category-select" className="detail-select" value={selected.category} onChange={e => updateTicket(selected.id, {category:e.target.value})}>{categories.map(c => <option key={c}>{c}</option>)}</select></div><button className="resolve-button" onClick={() => updateTicket(selected.id, {status: selected.status === 'Resolved' ? 'Open' : 'Resolved'})}>{selected.status === 'Resolved' ? 'Reopen ticket' : <><CheckCircle2 size={17}/> Mark as resolved</>}</button></> : <div className="empty-state">Select a ticket to see details.</div>}</div></section>
        <footer className="footer"><span>© 2026 HelpDesk. Keep every conversation moving.</span><span><i/> All systems operational</span></footer>
      </section>
    </main>
    {showCreate && <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && setShowCreate(false)}><section className="create-modal" role="dialog" aria-modal="true" aria-labelledby="create-heading"><div className="modal-heading"><div><div className="eyebrow">SUPPORT CENTER</div><h2 id="create-heading">Create a ticket</h2><p>Tell us what you need help with.</p></div><button className="icon-button" onClick={() => setShowCreate(false)} aria-label="Close form"><X size={20}/></button></div><form onSubmit={createTicket}><label className="form-label">Ticket title <span>*</span><input required maxLength="100" value={form.title} onChange={e => setForm({...form,title:e.target.value})} placeholder="Briefly describe the issue"/></label><label className="form-label">Description <span>*</span><textarea required rows="4" value={form.description} onChange={e => setForm({...form,description:e.target.value})} placeholder="Add details that will help us resolve your issue..."/></label><div className="form-two"><label className="form-label">Requester name <span>*</span><input required value={form.requester} onChange={e => setForm({...form,requester:e.target.value})} placeholder="Your name"/></label><label className="form-label">Email address <span>*</span><input required type="email" value={form.email} onChange={e => setForm({...form,email:e.target.value})} placeholder="you@example.com"/></label></div><div className="form-two"><label className="form-label">Category<select value={form.category} onChange={e => setForm({...form,category:e.target.value})}>{categories.map(c=><option key={c}>{c}</option>)}</select></label><label className="form-label">Priority<select value={form.priority} onChange={e => setForm({...form,priority:e.target.value})}>{priorities.map(p=><option key={p}>{p}</option>)}</select></label></div><div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setShowCreate(false)}>Cancel</button><button type="submit" className="primary-button"><Plus size={17}/> Create ticket</button></div></form></section></div>}
    {notice && <div className="toast"><CheckCircle2 size={18}/>{notice}<button onClick={() => setNotice('')} aria-label="Dismiss notification"><X size={15}/></button></div>}
  </div>
}
function Stat({icon,label,value,note,color}) { return <article className="stat-card"><div className={`stat-icon ${color}`}>{icon}</div><div className="stat-content"><span>{label}</span><strong>{value}</strong><small>{note}</small></div><div className={`stat-accent ${color}`}/></article> }
export default App
