# HelpDesk — Support Ticketing Tool

A responsive React + Vite frontend for creating and managing support tickets.

## Features
- Ticket list with search and status/priority filters
- Create ticket form with required fields and email validation
- Ticket details and editable status, priority, and category
- Mark tickets resolved or reopen them
- Dashboard summary cards
- Browser localStorage persistence
- Responsive layout for desktop, tablet, and mobile

## Run locally
Install Node.js (LTS), open a terminal in this folder, then run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Build for static hosting / GitHub Pages
```bash
npm run build
```
Vite creates a `dist` folder. Deploy the **contents of `dist`**, not the source folder, to a static host. `vite.config.js` uses a relative base path to support repository subpaths.

## Notes
This is a frontend demo. Tickets are stored only in the current browser and are not shared between users or devices. Replace the demo seed tickets or connect a backend/API for production use.
